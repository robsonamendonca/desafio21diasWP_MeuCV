=== Meu CV ===
Contributors: robsonamendonca
Tags: desafio,21Dias,tornese,programador, robsonamendonca, robson, wordpress, php, torneseumprogramador, programador
Donate link: https://www.buymeacoffee.com/robsonamendonca
Requires at least: 0.0.1
Tested up to: 0.0.1
Requires PHP: > 5.0
Stable tag: beta
License: GPLv3
License URI: https://www.gnu.org/licenses/quick-guide-gplv3.html

Crie seu CV online simples e rápido agora.

== Description ==
Este é o plugin criado pelo Robson aluno muito dedicado que acorda as 5 horas da manhã para evoluir 1% ao dia, esses alunos assim como o Robson são referências para mim: Danilo Aparecido.

== Installation ==
1 - Fazer o download do arquivo compactado ou acessar via site do Wordpress
2 - Instalar e ativar o plugin
3 - Cria post com os dados de cada sessão que compõem o currículo
 

== Screenshots ==
1. Modelo
2. cadastro
3. icone
